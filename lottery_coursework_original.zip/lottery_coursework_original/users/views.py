# IMPORTS
import logging
from datetime import datetime
from flask import Blueprint, render_template, flash, redirect, url_for, request, session
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.security import check_password_hash
from app import db
from models import User
from users.forms import RegisterForm, LoginForm
import pyotp


# CONFIG

users_blueprint = Blueprint('users', __name__, template_folder='templates')


# VIEWS

# View registration
@users_blueprint.route('/register', methods=['GET', 'POST'])
def register():
    # Create signup form object
    form = RegisterForm()

    # If request method is POST or form is valid
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        # If this returns a user, then the email already exists in database

        # If email already exists redirect user back to signup page with error message so user can try again
        if user:
            flash('Email address already exists')
            return render_template('register.html', form=form)

        # Create a new user with the form data
        new_user = User(email=form.email.data,
                        firstname=form.firstname.data,
                        lastname=form.lastname.data,
                        phone=form.phone.data,
                        password=form.password.data,
                        pin_key=form.pin_key.data,
                        role='user')

        # Add the new user to the database
        db.session.add(new_user)
        db.session.commit()

        # A message that a user has registered is sent to the security logs
        logging.warning('SECURITY - User registration [%s, %s]', form.email.data, request.remote_addr)

        # Sends user to login page
        return redirect(url_for('users.login'))
    # If request method is GET or form not valid re-render signup page
    return render_template('register.html', form=form)


# View user login
@users_blueprint.route('/login', methods=['GET', 'POST'])
def login():

    # Prevents user from logging in if they submit 3 incorrect logins in a single session
    if not session.get('logins'):
        # New session, set submission attempts to 0
        session['logins'] = 0
    elif session.get('logins') >= 3:
        flash('Number of incorrect logins exceeded')

    # Show form
    form = LoginForm()

    if form.validate_on_submit():
        # Increment login attempts
        session['logins'] += 1

        user = User.query.filter_by(email=form.email.data).first()
        if not user or not check_password_hash(user.password, form.password.data):
            # The user has entered incorrect details, this has been logged in the security log
            logging.warning('SECURITY - Invalid login attempt [%s, %s]', form.email.data, request.remote_addr)
            if session['logins'] == 3:
                flash('Number of attempts exceeded. You may try again later.')
            elif session['logins'] == 2:
                flash('Your details are incorrect. Number of attempts remaining: 1')
            else:
                flash('Your details are incorrect. Number of attempts remaining: 2')
            return render_template('login.html', form=form)

        # Verifies the pin
        if not pyotp.TOTP(user.pin_key).verify(form.pin.data):
            flash("You have supplied an invalid PIN")
        else:
            # Once the user is verified, reset
            session['logins'] = 0

            # Log the user in
            login_user(user)

            # Updates the current_logged_in and last_logged in fields
            user.last_logged_in = user.current_logged_in
            user.current_logged_in = datetime.now()
            db.session.add(user)
            db.session.commit()

            # This a valid login attempt, and is therefore logged in the security log
            logging.warning('SECURITY - Log in [%s, %s, %s]', current_user.id, current_user.email,
                            request.remote_addr)

            # Redirects the user to the correct page based on their role
            if user.role == 'admin':
                return redirect(url_for('admin.admin'))
            else:
                return redirect(url_for('users.profile'))

    return render_template('login.html', form=form)


# View user profile
@users_blueprint.route('/profile')
@login_required
def profile():
    return render_template('profile.html', user=current_user)


# View admin
@users_blueprint.route('/admin')
@login_required
def admin():
    return render_template('admin.html', name=current_user.firstname)


# View user account
@users_blueprint.route('/account')
@login_required
def account():
    # Passes the current_users detail into the template
    return render_template('account.html',
                           acc_no=current_user.id,
                           email=current_user.email,
                           firstname=current_user.firstname,
                           lastname=current_user.lastname,
                           phone=current_user.phone)


# View logout
@users_blueprint.route('/logout')
@login_required
def logout():
    # When the user logs out, a message is sent to the security log
    logging.warning('SECURITY - Log out [%s, %s, %s]', current_user.id, current_user.email, request.remote_addr)
    logout_user()
    # Then they're redirected to the index
    return redirect(url_for('index'))
