import re
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, PasswordField
from wtforms.validators import Required, Email, Length, EqualTo, ValidationError


# FUNCTIONS

# Checks that a given field contains none of the excluded characters below
def no_symbols(form, field):
    excluded_chars = "*?!'^+%&?()=}][{$#@<>"
    for char in field.data:
        if char in excluded_chars:
            raise ValidationError(f"Character {char} is not allowed.")


# REGISTRATION FORM SETUP

class RegisterForm(FlaskForm):
    # Fields are typed and have certain requirements to be accepted
    email = StringField(validators=[Required(), Email()])
    firstname = StringField(validators=[Required(), no_symbols])
    lastname = StringField(validators=[Required(), no_symbols])
    phone = StringField(validators=[Required()])
    password = PasswordField(validators=[
        Required(), Length(min=6, max=12, message='Password must be between 6 and 12 characters.')])
    confirm_password = PasswordField(validators=[
        Required(), EqualTo('password', message='Try again, passwords do not match.')])
    pin_key = StringField(validators=[Required(), Length(max=32, min=32, message="Length of PIN key must be 32.")])
    submit = SubmitField()

    # FUNCTIONS
    # Checks if password is valid
    def validate_password(self, password):
        # Does password contain at least 1 digit, 1 uppercase letter, 1 lower case letter and 1 symbol?
        p = re.compile(r'(?=.*\d)(?=.*[A-Z])(?=.*[a-z])(?=.*\W)')
        if not p.match(self.password.data):
            raise ValidationError(
                "Passwords must contain at least one special symbol, digit, lowercase and uppercase letter.")

    # Checks if phone number is valid
    def validate_phone(self, phone):
        # Is the phone number in the XXXX-XXX-XXXX format where all Xs are digits?
        ph = re.compile(r'(\d\d\d\d\-\d\d\d\-\d\d\d\d)')
        if not ph.match(self.phone.data):
            raise ValidationError("Please use the XXXX-XXX-XXXX format.")


# SETUP LOGIN FORM

class LoginForm(FlaskForm):
    # Fields are typed and have certain requirements to be accepted
    email = StringField(validators=[Required(), Email()])
    password = PasswordField(validators=[Required()])
    pin = StringField(validators=[Required(), Length(min=6, max=6, message="The pin is of incorrect length")])
    submit = SubmitField()
