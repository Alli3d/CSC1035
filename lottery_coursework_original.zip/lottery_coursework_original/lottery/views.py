# IMPORTS

from flask import Blueprint, render_template, request, flash
from flask_login import login_required, current_user
from app import db, requires_roles
from models import Draw, decrypt, encrypt

# CONFIG

lottery_blueprint = Blueprint('lottery', __name__, template_folder='templates')


# VIEWS

# View lottery page
@lottery_blueprint.route('/lottery')
@login_required
@requires_roles('user')
def lottery():
    return render_template('lottery.html')


# Add new draw
@lottery_blueprint.route('/add_draw', methods=['POST'])
@login_required
@requires_roles('user')
def add_draw():
    submitted_draw = ''
    for i in range(6):
        submitted_draw += request.form.get('no' + str(i + 1)) + ' '
    submitted_draw.strip()

    # Create a new draw with the form data (where the draw attribute is encrypted)
    new_draw = Draw(user_id=current_user.id, draw=encrypt(submitted_draw, current_user.draw_key), win=False, round=0)
    # Add the new draw to the database
    db.session.add(new_draw)
    db.session.commit()

    # Re-render lottery.page
    flash('Draw %s submitted.' % submitted_draw)
    return lottery()


# View all draws that have not been played
@lottery_blueprint.route('/view_draws', methods=['POST'])
@login_required
@requires_roles('user')
def view_draws():
    # Get all draws that have not been played [played=0]
    playable_draws = Draw.query.filter_by(played=False, user_id=current_user.id).all()

    # If playable draws exist
    if len(playable_draws) != 0:
        # Go through the list of playable_draws, decrypt the draw attribute of each object
        # and put the whole object back into Draw form so it can be properly read by
        # the template
        decrypted_draws = []
        for d in playable_draws:
            item = decrypt(d.draw, current_user.draw_key)
            new_draw = Draw(user_id=current_user.id, draw=item, win=False, round=0)

            decrypted_draws.append(new_draw)

        # Re-render lottery page with playable draws
        return render_template('lottery.html', playable_draws=decrypted_draws)
    else:
        flash('No playable draws.')
        return lottery()


# View lottery results
@lottery_blueprint.route('/check_draws', methods=['POST'])
@login_required
@requires_roles('user')
def check_draws():
    # Get played draws
    played_draws = Draw.query.filter_by(played=True, user_id=current_user.id).all()

    # If played draws exist
    if len(played_draws) != 0:
        # Go through the list of playable_draws, decrypt the draw attribute of each object
        # and put the whole object back into Draw form so it can be properly read by
        # the template
        decrypted_draws = []
        for d in played_draws:
            item = decrypt(d.draw, current_user.draw_key)
            new_draw = Draw(user_id=d.user_id, draw=item, win=d.win, round=d.round)

            decrypted_draws.append(new_draw)

        # Re-render lottery page with playable draws
        return render_template('lottery.html', playable_draws=decrypted_draws)

    # If no played draws exist [all draw entries have been played therefore wait for next lottery round]
    else:
        flash("Next round of lottery yet to play. Check you have playable draws.")
        return lottery()


# Delete all played draws
@lottery_blueprint.route('/play_again', methods=['POST'])
@login_required
@requires_roles('user')
def play_again():
    delete_played = Draw.__table__.delete().where(Draw.played, user_id=current_user.id)
    db.session.execute(delete_played)
    db.session.commit()

    flash("All played draws deleted.")
    return lottery()
